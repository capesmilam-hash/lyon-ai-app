import React from 'react';

interface LyonLogoProps {
  size?: number;
  showText?: boolean;
  className?: string;
}

export const LyonLogo: React.FC<LyonLogoProps> = ({ 
  size = 48, 
  showText = true, 
  className = "" 
}) => {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Lyon AI Emblem Badge */}
      <div 
        className="relative flex items-center justify-center rounded-2xl bg-gradient-to-br from-slate-800 via-slate-900 to-black p-2 border border-slate-700/80 shadow-lg shadow-cyan-500/10 hover:border-cyan-400/50 transition-all duration-300"
        style={{ width: size, height: size }}
      >
        {/* Glow effect */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 blur-sm -z-10" />
        
        {/* Futuristic Speech Bubble & Circuit Brain SVG */}
        <svg 
          viewBox="0 0 100 100" 
          className="w-full h-full drop-shadow-[0_0_8px_rgba(0,242,254,0.5)]"
          fill="none" 
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Metallic Speech Bubble Outer Ring */}
          <path 
            d="M 50,10 A 35,35 0 1,1 22,70 L 15,85 L 32,78 A 35,35 0 0,1 50,10 Z" 
            stroke="url(#metallicGradient)" 
            strokeWidth="5" 
            fill="#0b0f19"
          />
          
          {/* Circuit Lines & Neural Paths inside Brain */}
          <path 
            d="M35 38 Q 42 28 50 28 Q 58 28 65 38 Q 70 48 65 58 Q 58 68 50 68 Q 42 68 35 58 Z" 
            stroke="url(#neonGradient)" 
            strokeWidth="2.5" 
            strokeDasharray="100"
          />
          
          {/* Central AI Microchip */}
          <rect x="42" y="42" width="16" height="16" rx="3" fill="#0d1527" stroke="url(#neonGradient)" strokeWidth="1.5" />
          <text x="50" y="53" textAnchor="middle" fontSize="8" fontWeight="bold" fill="#00f2fe">AI</text>
          
          {/* Circuit Nodes */}
          <circle cx="35" cy="38" r="2" fill="#00f2fe" />
          <circle cx="65" cy="38" r="2" fill="#9d4edd" />
          <circle cx="35" cy="58" r="2" fill="#00f2fe" />
          <circle cx="65" cy="58" r="2" fill="#9d4edd" />
          <line x1="30" y1="48" x2="42" y2="48" stroke="#00f2fe" strokeWidth="1.5" />
          <line x1="58" y1="48" x2="70" y2="48" stroke="#9d4edd" strokeWidth="1.5" />

          {/* SVG Gradients */}
          <defs>
            <linearGradient id="metallicGradient" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#e2e8f0" />
              <stop offset="50%" stopColor="#64748b" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>
            <linearGradient id="neonGradient" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00f2fe" />
              <stop offset="100%" stopColor="#9d4edd" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Text Branding */}
      {showText && (
        <div className="flex flex-col">
          <span className="font-extrabold tracking-wider text-xl bg-gradient-to-r from-cyan-400 via-purple-300 to-indigo-400 bg-clip-text text-transparent drop-shadow-[0_0_10px_rgba(0,242,254,0.3)]">
            LYON
          </span>
          <span className="font-semibold text-xs tracking-widest text-cyan-400 uppercase -mt-1">
            AI
          </span>
        </div>
      )}
    </div>
  );
};
