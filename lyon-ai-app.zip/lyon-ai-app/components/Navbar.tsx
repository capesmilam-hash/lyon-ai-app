import React, { useState } from 'react';
import { LyonLogo } from './LyonLogo';
import { Cpu, Terminal, Shield, Zap, Sparkles, Menu, X } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-xl bg-slate-950/80 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Branding */}
          <a href="#" className="flex items-center gap-2 group">
            <LyonLogo size={46} showText={true} />
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-300">
            <a href="#playground" className="flex items-center gap-2 hover:text-cyan-400 transition-colors py-1">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>AI Playground</span>
            </a>
            <a href="#features" className="flex items-center gap-2 hover:text-cyan-400 transition-colors py-1">
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>Architecture</span>
            </a>
            <a href="#deploy" className="flex items-center gap-2 hover:text-cyan-400 transition-colors py-1">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Static vs Full-Stack</span>
            </a>
            <a href="#api" className="flex items-center gap-2 hover:text-cyan-400 transition-colors py-1">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>API Docs</span>
            </a>
          </div>

          {/* Action Badge & CTA */}
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>v1.0.0 Online</span>
            </div>
            
            <a 
              href="#playground" 
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold text-sm hover:opacity-90 shadow-lg shadow-cyan-500/20 transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>Try Lyon AI</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-950 border-b border-slate-800 px-4 pt-2 pb-6 space-y-3">
          <a href="#playground" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-slate-300 hover:text-cyan-400">AI Playground</a>
          <a href="#features" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-slate-300 hover:text-cyan-400">Architecture</a>
          <a href="#deploy" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-slate-300 hover:text-cyan-400">Static vs Full-Stack</a>
          <a href="#api" onClick={() => setMobileMenuOpen(false)} className="block py-2 text-slate-300 hover:text-cyan-400">API Docs</a>
        </div>
      )}
    </nav>
  );
};
