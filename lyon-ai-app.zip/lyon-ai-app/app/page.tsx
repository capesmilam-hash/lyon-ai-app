'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { LyonLogo } from '@/components/LyonLogo';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  Cpu, 
  Zap, 
  Layers, 
  Globe, 
  CheckCircle2, 
  Code2, 
  Server, 
  FileCode, 
  ArrowRight,
  Terminal,
  Activity
} from 'lucide-react';

interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  time: string;
  latency?: number;
}

export default function HomePage() {
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: 'Welcome to Lyon AI. Send a message to test the Neural Circuit engine or explore static export capabilities.',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      latency: 24,
    }
  ]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userText = inputMessage.trim();
    const userMsg: ChatMessage = {
      sender: 'user',
      text: userText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatHistory((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Call Full-Stack Next.js API Route
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userText })
      });

      if (res.ok) {
        const data = await res.json();
        setChatHistory((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: data.reply,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            latency: data.latencyMs
          }
        ]);
      } else {
        throw new Error('API request failed');
      }
    } catch (err) {
      // Fallback for static HTML exports or offline testing
      setTimeout(() => {
        let fallbackReply = `[Lyon AI Client Engine]: Processed message "${userText}". Running in fallback / static mode.`;
        if (userText.toLowerCase().includes('static') || userText.toLowerCase().includes('export')) {
          fallbackReply = "Lyon AI supports static site generation (`output: 'export'`)! Client-side AI integrations or external REST/GraphQL APIs function seamlessly without a dedicated Node backend.";
        }
        setChatHistory((prev) => [
          ...prev,
          {
            sender: 'ai',
            text: fallbackReply,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            latency: 18
          }
        ]);
      }, 500);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col bg-grid-pattern">
      {/* Navigation Header */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-24">
        
        {/* HERO SECTION */}
        <section className="text-center space-y-8 pt-8">
          
          {/* Top Pill Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 text-sm text-cyan-300 shadow-xl shadow-cyan-500/10">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>Next.js Full-Stack & Static Export Architecture</span>
          </div>

          {/* Large Branding Showcase */}
          <div className="flex flex-col items-center justify-center gap-6">
            <LyonLogo size={110} showText={false} className="hover:scale-105 transition-transform duration-300" />
            
            <h1 className="text-4xl sm:text-6xl font-black tracking-tight max-w-3xl">
              Next-Gen Neural Intelligence with{' '}
              <span className="bg-gradient-to-r from-cyan-400 via-purple-400 to-indigo-400 bg-clip-text text-transparent glow-cyan">
                LYON AI
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-slate-400 max-w-2xl font-normal leading-relaxed">
              A high-performance Next.js application template built with Tailwind CSS, TypeScript, full-stack API routes, and seamless static site export support (`output: 'export'`).
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <a 
              href="#playground" 
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold flex items-center gap-2 shadow-lg shadow-cyan-500/25 hover:opacity-95 transition-all"
            >
              <Terminal className="w-5 h-5" />
              <span>Launch AI Playground</span>
            </a>
            
            <a 
              href="#deploy" 
              className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 font-semibold flex items-center gap-2 transition-all"
            >
              <Code2 className="w-5 h-5 text-purple-400" />
              <span>View Export Guide</span>
            </a>
          </div>

        </section>

        {/* INTERACTIVE AI PLAYGROUND SECTION */}
        <section id="playground" className="space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-3">
                <Cpu className="w-6 h-6 text-cyan-400" />
                <span>Lyon AI Interactive Playground</span>
              </h2>
              <p className="text-sm text-slate-400">Test real-time neural processing via Next.js API route `/api/chat`</p>
            </div>
            
            <div className="hidden sm:flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-400">
              <Activity className="w-4 h-4 text-emerald-400" />
              <span>Latency: ~24ms</span>
            </div>
          </div>

          {/* Chat Window Box */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl flex flex-col h-[520px]">
            
            {/* Header bar of Terminal */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                </div>
                <span className="text-xs font-mono text-slate-400 pl-2">lyon-ai-neural-console.ts</span>
              </div>
              <span className="text-xs font-mono px-2.5 py-1 rounded bg-cyan-950/80 border border-cyan-800/80 text-cyan-400">
                Model: lyon-neural-v1
              </span>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {chatHistory.map((msg, index) => (
                <div 
                  key={index} 
                  className={`flex gap-3 max-w-3xl ${msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
                >
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    msg.sender === 'user' 
                      ? 'bg-purple-600/30 border border-purple-500/50 text-purple-300' 
                      : 'bg-cyan-950/80 border border-cyan-500/50 text-cyan-400'
                  }`}>
                    {msg.sender === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                  </div>

                  <div className={`rounded-2xl px-5 py-3.5 text-sm leading-relaxed space-y-1 ${
                    msg.sender === 'user'
                      ? 'bg-purple-900/40 border border-purple-800/60 text-slate-100 rounded-tr-none'
                      : 'bg-slate-950/90 border border-slate-800/90 text-slate-200 rounded-tl-none shadow-md'
                  }`}>
                    <p>{msg.text}</p>
                    <div className="flex items-center justify-between gap-4 text-[11px] text-slate-500 pt-1">
                      <span>{msg.time}</span>
                      {msg.latency && <span>{msg.latency}ms</span>}
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-center gap-3 text-sm text-cyan-400 animate-pulse pt-2">
                  <Bot className="w-5 h-5" />
                  <span>Lyon AI is processing neural tensor weights...</span>
                </div>
              )}
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendMessage} className="p-4 bg-slate-950 border-t border-slate-800 flex gap-3">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask Lyon AI a question or request code generation..."
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 focus:outline-none focus:border-cyan-500/80 focus:ring-1 focus:ring-cyan-500/80 placeholder:text-slate-500"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 font-semibold text-white text-sm hover:opacity-90 disabled:opacity-50 flex items-center gap-2 shadow-md shadow-cyan-500/20"
              >
                <span>Send</span>
                <Send className="w-4 h-4" />
              </button>
            </form>

          </div>
        </section>

        {/* ARCHITECTURE & FEATURES SECTION */}
        <section id="features" className="space-y-12">
          <div className="text-center space-y-3">
            <h2 className="text-3xl font-bold tracking-tight">Built for Performance & Scale</h2>
            <p className="text-slate-400 max-w-xl mx-auto">Explore key architectural highlights of the Lyon AI Next.js template.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Card 1 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-cyan-500/40 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
                <Server className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-100">Full-Stack Server Mode</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Utilize Next.js App Router API Routes (`app/api/*`) for server-side execution, database connections, API key security, and streaming AI responses.
              </p>
            </div>

            {/* Card 2 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-purple-500/40 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-purple-950 border border-purple-800/60 flex items-center justify-center text-purple-400">
                <Globe className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-100">Static Export Mode</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Uncomment `output: 'export'` in `next.config.js` to build fully static HTML, CSS, and JS assets for deployment on GitHub Pages, S3, or Vercel CDN.
              </p>
            </div>

            {/* Card 3 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-indigo-500/40 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-950 border border-indigo-800/60 flex items-center justify-center text-indigo-400">
                <FileCode className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-slate-100">Tailwind & TypeScript</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Fully typed TypeScript components paired with customized Tailwind CSS theme extending Lyon AI colors (cyan, purple, metallic dark).
              </p>
            </div>

          </div>
        </section>

        {/* DEPLOYMENT & EXPORT GUIDE SECTION */}
        <section id="deploy" className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 sm:p-12 space-y-8 backdrop-blur-md">
          <div className="space-y-2">
            <span className="text-xs font-mono uppercase tracking-widest text-cyan-400">Deployment Options</span>
            <h2 className="text-3xl font-bold">How to Run & Deploy Lyon AI</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Full Stack Node Option */}
            <div className="space-y-4 p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-lg">1. Full-Stack Node.js Deployment</h3>
              </div>
              <p className="text-sm text-slate-400">Default mode. Provides full Node server features and backend API handlers.</p>
              
              <div className="p-4 rounded-xl bg-slate-900 font-mono text-xs text-slate-300 space-y-2">
                <div className="text-slate-500"># Development server</div>
                <div className="text-cyan-300">npm run dev</div>
                <div className="text-slate-500 pt-2"># Production build & start</div>
                <div className="text-cyan-300">npm run build && npm run start</div>
              </div>
            </div>

            {/* Static Export Option */}
            <div className="space-y-4 p-6 rounded-2xl bg-slate-950 border border-slate-800">
              <div className="flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-lg">2. Static File Export (`output: 'export'`)</h3>
              </div>
              <p className="text-sm text-slate-400">Exports static site files directly into the `/out` directory.</p>
              
              <div className="p-4 rounded-xl bg-slate-900 font-mono text-xs text-slate-300 space-y-2">
                <div className="text-slate-500"># Enable static export in next.config.js</div>
                <div className="text-purple-300">module.exports = {'{'} output: 'export' {'}'}</div>
                <div className="text-slate-500 pt-2"># Generate static files inside /out</div>
                <div className="text-cyan-300">npm run build</div>
              </div>
            </div>

          </div>
        </section>

      </main>

      {/* FOOTER */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-12 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <LyonLogo size={40} showText={true} />
          <p className="text-xs text-slate-500">
            © 2026 Lyon AI Platform. Next.js Full-Stack Application Template.
          </p>
        </div>
      </footer>
    </div>
  );
}
