import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'online',
    system: 'Lyon AI Core Cluster',
    version: '1.0.0',
    deploymentMode: process.env.NEXT_PUBLIC_STATIC_EXPORT === 'true' ? 'Static Export' : 'Full-Stack Next.js Node.js',
    gpuNodesActive: 32,
    averageLatencyMs: 42,
    uptimePercentage: 99.98,
    supportedModels: [
      { id: 'lyon-neural-v1', name: 'Lyon Neural Core v1', type: 'LLM Reasoning' },
      { id: 'lyon-vision-circuit', name: 'Lyon Vision Circuit', type: 'Multimodal Image' },
      { id: 'lyon-code-synth', name: 'Lyon Code Synth', type: 'Code Generation' }
    ],
    timestamp: new Date().toISOString()
  });
}
