import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { message, model = 'lyon-neural-v1' } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Prompt message is required' },
        { status: 400 }
      );
    }

    // Simulated Lyon AI Neural Engine Processing Logic
    const startTime = Date.now();
    
    // Custom Intelligent Mock Responses tailored to Lyon AI
    let reply = "";
    const lowerMessage = message.toLowerCase();

    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
      reply = "Greetings! I am Lyon AI, your neural circuit intelligence assistant. How can I assist your workflow today?";
    } else if (lowerMessage.includes('static') || lowerMessage.includes('export') || lowerMessage.includes('next.js')) {
      reply = "Lyon AI Next.js template supports dual deployment modes! You can run full-stack server mode with Node.js API routes, or export static HTML/JS files (`output: 'export'`) for ultra-fast CDN deployment on GitHub Pages, Cloudflare Pages, or AWS S3.";
    } else if (lowerMessage.includes('logo') || lowerMessage.includes('brand')) {
      reply = "The Lyon AI emblem features a metallic speech bubble encircling a neural circuit brain with a core AI microchip. It symbolizes speech synthesis, deep reasoning, and high-throughput AI processing.";
    } else {
      reply = `[Lyon AI Response]: Processed prompt: "${message}". The neural engine synthesized high-dimensional embeddings across active Transformer layers and returned optimal parameters.`;
    }

    const executionTimeMs = Date.now() - startTime + 120; // add mock inference latency

    return NextResponse.json({
      success: true,
      model: model,
      reply: reply,
      usage: {
        promptTokens: message.length,
        completionTokens: reply.length,
        totalTokens: message.length + reply.length,
      },
      latencyMs: executionTimeMs,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to process prompt through Lyon AI pipeline' },
      { status: 500 }
    );
  }
}
