import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Lyon AI - Neural Circuit Intelligence Platform',
  description: 'Next.js Full-Stack Application & Static Export Template powered by Lyon AI',
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
        {children}
      </body>
    </html>
  );
}
